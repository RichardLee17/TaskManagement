package com.bau.taskportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskportalApplication.class, args);
	}

}
